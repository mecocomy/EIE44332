import dotenv from 'dotenv';
dotenv.config({ path: '.env' });

const CONNECTION_STR = `mongodb+srv://2274877917:ptLTsjMmjMbk5PH8@cluster0.uthlw3c.mongodb.net/?retryWrites=true&w=majority`;
const config = {
  CONNECTION_STR: CONNECTION_STR,
};

if (!config.CONNECTION_STR) {
  console.error(`CONNECT_STR is not define`);
  dotenv.process.exit(1);
}

export default config;
