import express from 'express';
import session from 'express-session';
import login from './login.js';
//import register from './register.js';

const app = express();

app.use(
 session({
 secret: '4432',
 resave: false,
 saveUninitialized: false,
 cookie: { httpOnly: true },
 })
);

app.get('/', (req, res) => {
    res.redirect('/login.html');
});

app.listen(8080, () => {
  console.log('Server started at http://127.0.0.1:8080');
});


app.use('/auth', login);
//app.use('/auth',register);
app.use('/', express.static('static'));