// import express from 'express';
// import multer from 'multer';
// import * as fs from 'fs/promises';
// //import { validate_user, update_user, fetch_user, username_exist } from 'userdb.js';

// //创建一个初始的userdatabase
// const users = new Map();

// //初始化userdatabase 让它等于users.json 中的内容：
// async function init_userdb() {
//   try {
//     //如果不为空，返回当前值
//     if (users.size > 0) {
//       return;
//     }
//     //为空的化，初始化
//     const userData = await fs.readFile('users.json', 'utf-8');
//     const userObjects = JSON.parse(userData);

//     userObjects.forEach((user) => {
//       const username = user.username;
//       users.set(username, user);
//     });
//   } catch (err) {
//     console.error('error', err);
//   }
// }

// //创建一个函数用来更改和添加user.json中的保存信息
// async function update_user(username, password, role,firstname,lastname,gender,email) {
//   try {
//     const userData = await fs.readFile('users.json', 'utf-8');
//     //用来解析JSON，可以通过users.username来调出其中的value
//     const users = JSON.parse(userData);
//     //使用username作为Key来找到user object.
//     const userIndex = users.findIndex((user) => user.username === username);
//     //如果能找到相应的object的话：
//     if (userIndex !== -1) {
//       users[userIndex].password = password;
//       users[userIndex].role = role;
//       users[userIndex].firstname = firstname;
//       users[userIndex].lastname = lastname;
//       users[userIndex].gender = gender;
//       users[userIndex].email = email;
//       //如果找不到这个object 的话那么就重新创建一个新的：
//     } else {
//       const newUser = {
//         username: username,
//         password: password,
//         role: role,
//         firstname : firstname,
//         lastname : lastname,
//         gender : gender,
//         email : email,
//       };
//       //添加到arraylist里面：
//       users.push(newUser);
//     }

//     //把array变成json:
//     const userjson = [];
//     users.forEach((user) => userjson.push(user));
//     const userjsonString = JSON.stringify(userjson, null, 2);

//     //把输出内容写到file当中：
//     fs.writeFile('users.json', userjsonString);
//     return true;
//   } catch (err) {
//     console.error(err);
//     return false;
//   }
// }

// async function validate_user(username, password) {
//   try {
//     const user = users.get(username);
//     if (user==='') {
//       console.log('User does not exist.');
//       return false;
//     }

//     if (user.password !== password) {
//       console.log('Password mismatch.');
//       return false;
//     }

//     return {
//       username: user.username,
//       role: user.role,
//     };
//   } catch (error) {
//     console.error('error:', error);
//   }
// }

// //对post方法进行响应(register)
// const route = express.Router();
// const form = multer();

// route.use(form.none());
// // route.post('/register', async (req, res) => {
// //   try {
// //     if (users.size === 0) {
// //       init_userdb();
// //     }
// //     const username = req.body?.username;
// //     const password = req.body?.password;
// //     const role = req.body?.role;
// //     const firstname = req.body?.firstname;
// //     const lastname = req.body?.lastname;
// //     const gender = req.body?.gender;
// //     const email = req.body?.email;


// //     //检查username 和 password 是否为空：
// //     if (username==='' || password==='') {
// //       return res.status(400).json({ status: 'failed', message: 'Missing fields' });
// //     }
// //     //检查username是否小于三：
// //     if (username.length < 3) {
// //       return res.status(400).json({ status: 'failed', message: 'Username must be at least 3 characters' });
// //     }
// //     //检查username是否存在：
// //     if (users.has(username)) {
// //       return res.status(400).json({ status: 'failed', message: 'Username ' + username + ' already exist' });
// //     }
// //     //检查password是否小于八：
// //     if (password.length < 8) {
// //       return res.status(400).json({ status: 'failed', message: 'Password must be at least 8 characters' });
// //     }
// //     //检查role:
// //     if (role !== 'admin' && role !== 'user') {
// //       return res.status(400).json({ status: 'failed', message: 'Role can only be either `Admin` or `user`' });
// //     }
// //     //创建新的user:
// //     const user = await update_user(username, password, role,firstname,lastname,gender,email);
// //     if (user) {
// //       return res.status(200).json({ status: 'success', user: { username, role } });
// //     } else {
// //       return res
// //         .status(500)
// //         .json({ status: 'failed', message: 'Account created but unable to save into the database' });
// //     }
// //   } catch (error) {
// //     console.log(error);
// //     return res.status(500).json({ status: 'failed', message: 'Internal server error' });
// //   }
// // });


// // route.post('/login', async (req, res) => {
// //    if (users.size === 0) {
// //    await init_userdb();
// //    }
// //    if (req.session.logged === true) {
// //    req.session.logged = false;
// //    }
  
// //    const user = await validate_user(req.body?.username, req.body?.password);
// //    if (user) {
// //    req.session.username = user.ID;
// //    req.session.role = user.role;
// //    req.session.logged = true;
// //    res.json({ status: 'success', user: { username: user.username, role: user.role } });
// //    } else {
// //    res.status(401).json({ status: 'failed', message: 'Incorrect username and password' });
// //    }
// //   });

  
// // route.post('/logout', async (req, res) => {
// //   if (req.session.logged === true) {
// //     req.session.destroy();
// //     res.end();
// //   } else {
// //     res.json({ status: 'failed', message: 'Unauthorized' });
// //   }
// // });

// // route.get('/me', async (req, res) => {
// //   if (req.session.logged === true) {
// //     const user = fetch_user(req.session.username);
// //     res.json({ status: 'success', user: { username: user.username, role: user.role } });
// //   } else {
// //     res.json({ status: 'failed', message: 'Unauthorized' });
// //   }
// // });



// //const app = express();


// // 创建一个初始的userdatabase



// // 验证用户登录信息


// // route.use(form.none());

// // // 处理登录请求
// // route.post('/login', async (req, res) => {
// //   try {
// //     if (users.size === 0) {
// //       await init_userdb();
// //     }

// //     const role = req.body.role;
// //     const username = req.body.id;
// //     const password = req.body.password;

// //     if (!role || !username || !password) {
// //       return res.status(400).json({ status: 'failed', message: 'Missing fields' });
// //     }

// //     const user = await validate_user(username, password, role);
// //     if (user) {
// //       return res.status(200).json({ status: 'success', user: { username: user.username, role: user.role } });
// //     } else {
// //       return res.status(401).json({ status: 'failed', message: 'Incorrect username and password' });
// //     }
// //   } catch (error) {
// //     console.log(error);
// //     return res.status(500).json({ status: 'failed', message: 'Internal server error' });
// //   }
// // });

// export default route;