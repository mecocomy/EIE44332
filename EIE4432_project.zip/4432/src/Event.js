// 导入所需的库和模块
import express from 'express';
import bodyParser from 'body-parser';

// 创建 Express 应用程序
var app = express();

// 使用 body-parser 中间件解析请求体
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// 保存演唱会事件的数据
var event = null;

// 处理来自管理页面的 POST 请求以创建新的演唱会事件
app.post('/auth/Event', function(req, res) {
  // 获取请求体中的数据
  var name = req.body.name;
  var date = req.body.date;
  var price = req.body.price;
  var venue = req.body.venue;
  var musician = req.body.musician;


  // 保存事件数据
  event = {
    name: name,
    date: date,
    price: price,
    venue: venue,
    musician: musician
  };

  // 返回成功的响应
  res.json({ success: true });
});

// 处理来自座位管理页面的 POST 请求以创建座位管理数据
app.post('/auth/Event', function(req, res) {
  // 获取请求体中的数据
  var noLine = req.body.noLine;
  var noColumn = req.body.noColumn;
  var priceA = req.body.priceA;
  var priceB = req.body.priceB;
  var priceC = req.body.priceC;

  // 将座位管理数据与事件数据合并
  event.noLine = noLine;
  event.noColumn = noColumn;
  event.priceA = priceA;
  event.priceB = priceB;
  event.priceC = priceC;

  // 返回成功的响应
  res.json({ success: true });
});

// 处理来自事件日期板页面的 GET 请求以获取事件数据
app.get('/auth/Event', function(req, res) {
  // 返回事件数据
  res.json(event);
});

// 启动服务器
// app.listen(3000,function() {
//   console.log('服务器已启动，监听端口 3000');
// });