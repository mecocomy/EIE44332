document.addEventListener('DOMContentLoaded', () => {
  const loginButton = document.getElementById('loginButton');
  const registerButton = document.getElementById('registerButton');
  const rememberIdCheckbox = document.getElementById('remember');
  const idInput = document.getElementById('username');

  const rememberedId = localStorage.getItem('remember');
    if (rememberedId) {
        idInput.value = rememberedId;
        rememberIdCheckbox.checked = true;
    }

    loginButton.addEventListener('click', () => {
        const role = document.getElementById('role').value;
        const id = idInput.value;
        const password = document.getElementById('password').value;

        if (!id || !password) {
            alert('ID and password cannot be empty');
            return;
        }

        // 如果用户勾选了记住ID选项，则将ID保存到本地存储
        if (rememberIdCheckbox.checked) {
            localStorage.setItem('rememberedId', id);
        } else {
            localStorage.removeItem('rememberedId');
        }
      })

  registerButton.addEventListener("click", () => {
    window.location.href = "../register.html";
  });

  loginButton.addEventListener('click', () => {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    if (!username || !password) {
      alert('Username and password cannot be empty');
      return;
    }

    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);

    fetch('http://127.0.0.1:8080/auth/login', {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        if (data.status === "success") {
          alert(`Logged as '${data.user.username}' (${data.user.role})`);
          if (role === 'admin') {
            window.location.href = '../Event Dashboard.html';
          }
          else if (role === 'user') {
            window.location.href = '../Event_user.html';
          }
        } else if (data.status === "failed") {
          alert(data.message);
        } else {
          alert("Unknown error");
        }
      })
      .catch(error => {
        console.log('Error:', error);
      });
  });

  
})

