document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('register').onclick = function (event) {
        event.preventDefault();
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var confirmPassword = document.getElementById('R-p').value;
        var role = document.getElementById('role').value;
        var firstname = document.getElementById('firstname').value;
        var lastname = document.getElementById('lastname').value;
        var gender = document.getElementById('gender').value;
        var email = document.getElementById('email').value;


        //检查username & password是否为空
        if (username.trim() === '' || password.trim() === '') {
            alert('Username and password cannot be empty');
            return;
        }

        //检查两次输入的password是否一致
        if (password !== confirmPassword) {
            alert('Password mismatch!');
            return;
        }

        //检查role是否为空
        if (role === 'default') {
            alert('Please select your role!');
            return;
        }
        //检查gender是否为空
        if (gender === 'default') {
            alert('Please select your gender!');
            return;
        }
        //检查Name是否为空
        if (firstname.trim() === '' || lastname.trim() === '') {
            alert('Name cannot be empty!');
            return;
        }
        //检查Email是否为空
        if (email.trim() === '') {
            alert('Email cannot be empty!');
            return;
        }
        if (role === "admin") {
                document.getElementsByClassName("fail")[0].classList.remove("d-none");
                document.getElementById("fail_ms").textContent = "Registration failed!";
            
        }
        else{
            document.getElementsByClassName("successful")[0].classList.remove("d-none");
            document.getElementById("successful_ms").textContent = "Rgistration succeeded!";
        

        //成功注册之后
        var formData = new FormData();
        formData.append('username', username);
        formData.append('password', password);
        formData.append('role', role);
        formData.append('firstname', firstname);
        formData.append('lastname', lastname);
        formData.append('gender', gender);
        formData.append('email', email);

        fetch('/auth/register', {
        method: 'POST',
        body: formData,
        })
        .then(function (response) {
            if(role === "user"){
                return response.json();
            }
            else if(role === "admin" || username === "admin" ||password === "adminpass"){
                return response.json()
            }
        })
        .then(function (data) {
            if (data.status === 200 || data.status === 'success') {
            var username = document.getElementById('username').value;
            alert('Welcome,' + username + '! \r\nYou can login with your account now!');
            window.location.href = '../login.html';
            } else {
            alert(data.message);
            document.getElementsByClassName("fail")[0].classList.remove("d-none");
            document.getElementById("fail_ms").textContent = "Registration failed!";
            }
        })
        .catch(function (error) {
            console.error('Error:', error);
        });
        };

    };
    document.getElementById('back').onclick = function (event){
      window.location.href = '../login.html';
    }
});
