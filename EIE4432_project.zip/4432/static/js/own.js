// 获取相关元素
var editButton = document.getElementById("editButton");
var overlay = document.getElementsByClassName("overlay")[0];
var modal = document.getElementsByClassName("modal")[0];
var saveButton = document.getElementById("saveButton");

// 当点击"Update"按钮时显示弹出层
editButton.addEventListener("click", function() {
    overlay.style.display = "flex";
});

// 当点击"Save"按钮时保存输入的信息并更新卡片内容
saveButton.addEventListener("click", function() {
    var nickNameInput = document.getElementById("nickNameInput");
    var firstNameInput = document.getElementById("firstNameInput");
    var lastNameInput = document.getElementById("lastNameInput");
    var emailInput = document.getElementById("emailInput");
    var birthdayInput = document.getElementById("birthdayInput");
    var nickName = document.getElementById("nickName");
    var firstName = document.getElementById("firstName");
    var lastName = document.getElementById("lastName");
    var email = document.getElementById("email");
    var birthday = document.getElementById("Birthday");

    // 更新卡片内容
    nickName.textContent = nickNameInput.value;
    firstName.textContent = firstNameInput.value;
    lastName.textContent = lastNameInput.value;
    email.textContent = emailInput.value;
    birthday.textContent = birthdayInput.value;

    // 隐藏弹出层
    overlay.style.display = "none";
});

// 显示/隐藏输入框
editButton.addEventListener("click", function() {
    modal.style.display = "block";
});

// 隐藏输入框
saveButton.addEventListener("click", function() {
    modal.style.display = "none";
});