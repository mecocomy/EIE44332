document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('fileInput');
    const preview = document.getElementById('preview');
    const placeholder = document.getElementById('placeholder');
    const nameInput = document.getElementById('inputN');
    const dateInput = document.getElementById('Date');
    const priceInput = document.getElementById('inputP');
    const venueInput = document.getElementById('inputV');
    const musicianInput = document.getElementById('inputM');
    const descriptionInput = document.getElementById('inputD');

    const submitButton = document.getElementById('submitButton');
  
    fileInput.addEventListener('change', function(event) {
      const file = event.target.files[0];
  
      if (file) {
        const reader = new FileReader();
  
        reader.addEventListener('load', function() {
          const image = document.createElement('img');
          image.src = reader.result;
  
          preview.innerHTML = '';
          preview.appendChild(image);
  
          placeholder.style.display = 'none';
        });
  
        reader.readAsDataURL(file);
      } else {
        placeholder.style.display = 'block';
      }
    });

    submitButton.addEventListener('click', function() {
      const name = nameInput.value;
      const date = dateInput.value;
      const price = priceInput.value;
      const venue = venueInput.value;
      const musician = musicianInput.value;
      const description = descriptionInput.value;
      const file = fileInput.files[0];
      alert("Event upload successful!");
      
      //const url = 'Event Dashboard.html' + '?name=' + encodeURIComponent(name) + '&date=' + encodeURIComponent(date) + '&price=' + encodeURIComponent(price) + '&venue=' + encodeURIComponent(venue) + '&musician=' + encodeURIComponent(musician) + '&description=' + encodeURIComponent(description) + '&image=' + encodeURIComponent(imageDataURL);
      window.location.href = '../Event Dashboard.html';
  });
})

