// 座位图尺寸
var rows = 15;
var cols = 25;

// 座位图状态
var seatMap = [];

// 创建座位图
var seatMapElement = document.getElementById("seatMap");

// 添加舞台横线
var stageRow = document.createElement("tr");
stageRow.classList.add("stage");
var stageCell = document.createElement("td");
stageCell.setAttribute("colspan", cols);
stageCell.textContent = "edge";
stageRow.appendChild(stageCell);
seatMapElement.appendChild(stageRow);

// 标注行列数字
var numberRow = document.createElement("tr");
var numberHeader = document.createElement("td");
var numberCell = document.createElement("td");
numberRow.appendChild(numberHeader);

for (var a = 0; a < cols; a++) {
    numberCell.textContent = a + 1;
    numberRow.appendChild(numberCell);
}

seatMapElement.appendChild(numberRow);

for (var i = 0; i < rows; i++) {
    var row = document.createElement("tr");
    
    numberCell.textContent = i + 1;
    row.appendChild(numberCell);
    var seatMapRow = [];
    
    for (var j = 0; j < cols; j++) {
        var seat = document.createElement("td");
        seat.dataset.row = i;
        seat.dataset.col = j;
        seat.addEventListener("click", function() {
            var row = parseInt(this.dataset.row);
            var col = parseInt(this.dataset.col);
            
            if (seatMap[row][col] === 0) {
                seatMap[row][col] = 1;
                this.classList.add("selected");
            } else if (seatMap[row][col] === 1) {
                seatMap[row][col] = 0;
                this.classList.remove("selected");
            }
            
            updateSelectedSeat();
        });
        
        row.appendChild(seat);
        seatMapRow.push(0);
    }
    
    seatMap.push(seatMapRow);
    seatMapElement.appendChild(row);
}

// 更新选中的座位信息
// 更新选中的座位信息
function updateSelectedSeat() {
    var selectedSeat = document.getElementById("selectedSeat");
    selectedSeat.innerHTML = "";

    var seats = []; // 存储选中的座位信息

    for (var i = 0; i < rows; i++) {
        for (var j = 0; j < cols; j++) {
            if (seatMap[i][j] === 1) {
                var seatInfo = document.createElement("span");
                seatInfo.textContent = "Line: " + (i + 1) + " Row: " + (j + 1) + ", ";
                selectedSeat.appendChild(seatInfo);
                // 将选中的座位信息添加到seats数组中
                seats.push("Line: " + (i + 1) + " Row: " + (j + 1));
            }
        }
    }

    // 将座位信息存储在sessionStorage中
    sessionStorage.setItem("seats", JSON.stringify(seats));

    // 检查是否有选中的座位，启用或禁用提交按钮
    var submitButton = document.getElementById("submitButton");
    submitButton.disabled = selectedSeat.innerHTML === "";
}

// 提交预定
// 提交预定
// 提交预定
var submitButton = document.getElementById("submitButton");
submitButton.addEventListener("click", function() {
    // 显示确认对话框
    var isConfirmed = confirm("Confirm booking?");
    
    if (isConfirmed) {
        submitButton.disabled = true;  // 禁用提交按钮，避免重复点击
        
        for (var i = 0; i < rows; i++) {
            for (var j = 0; j < cols; j++) {
                if (seatMap[i][j] === 1) {
                    seatMap[i][j] = 2;
                    var seat = document.querySelector("td[data-row='" + i + "'][data-col='" + j + "']");
                    seat.classList.remove("selected");
                    seat.classList.add("booked");
                    seat.removeEventListener("click");
                }
            }
        }
        
        alert("Book successfully!");
        updateSelectedSeat();

        
    }
   
});

var payButton = document.getElementById("pay");
payButton.addEventListener("click", function() {
  var seats = sessionStorage.getItem("seats");

  var detailUrl = "detail.html?message=" + encodeURIComponent(seats);
  window.location.href = detailUrl;
});